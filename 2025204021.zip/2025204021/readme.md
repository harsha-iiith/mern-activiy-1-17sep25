# Mern Lab 1

## Files that i have changed

## 1) In ./backend/.env

## provided .env.example for reference

```bash
PORT=3000
MONGO_URI=mongodb://127.0.0.1:27017/labactivity1
NODE_ENV=test
```

## 2) In ./backend/src/server.js

## Called connectDB function in server.js

```javascript
// server.js
import { connectDB } from "./config/db.js";

// Only start the server if NOT in test mode
if (process.env.NODE_ENV !== "test") {
  // Connect to MongoDB
  await connectDB();

  // Start the server
  app.listen(PORT, () => {
    console.log("Server started on PORT:", PORT);
  });
}
```

## 3) In ./backend/src/models/notes.model.js

```javascript
// from documentation created code in this
// notes.model.js
import mongoose, { Schema } from "mongoose";

const NotesSchema = new Schema({
  id: String,
  title: String,
  content: String,
});

export default mongoose.model("Notes", NotesSchema);
```

## 4) In ./backend/src/controller/notesController.js

## Now using this i have updated the code in the controller to get our full functionality

## Added an extra route to get the number of notes

```javascript
// In ./backend/src/controller/notesController.js

// used try catch and imported the model and used for all the endpoints including the extra endpoint(to get the number of notes)

import Notes from "../models/notes.model.js";
import { v4 as uuidv4 } from "uuid";
// GET all notes
export async function getAllNotes(req, res) {
  try {
    const notes = await Notes.find();
    res.status(200).json(notes);
    return;
  } catch (err) {
    res.status(500).json({ error: "Failed to get notes" });
    return;
  }
}

// POST create note
export async function createNotes(req, res) {
  try {
    const { title, content } = req.body;
    if (!title || !content) {
      res.status(400).json({ error: "Title and content required" });
      return;
    }

    const id = uuidv4();
    const note = await Notes.create({ id, title, content });
    res.status(201).json(note);
    return;
  } catch (err) {
    res.status(500).json({ error: "Failed to create note" });
    return;
  }
}

// PUT update note by id
export async function updateNotes(req, res) {
  try {
    const { id } = req.params;
    console.log(id);
    if (!id) {
      res.status(400).json({ error: "ID required" });
      return;
    }
    const { title, content } = req.body;
    console.log(title, content);

    if (!title || !content) {
      res.status(400).json({ error: "Title and content required" });
      return;
    }

    const task = await Notes.findOne({ id });

    if (!task) {
      res.status(404).json({ error: "Note not found" });
      return;
    }

    const updatedTask = await Notes.findOneAndUpdate(
      { id },
      { title, content },
      { new: true }
    );
    res.status(200).json(updatedTask);
    return;
  } catch (err) {
    res.status(500).json({ error: "Failed to update note" });
    return;
  }
}

// DELETE note by id
export async function deleteNotes(req, res) {
  try {
    const { id } = req.params;
    if (!id) {
      res.status(400).json({ error: "ID required" });
      return;
    }

    const task = await Notes.findOne({ id });
    if (!task) {
      res.status(404).json({ error: "Note not found" });
      return;
    }
    const deletedNote = await Notes.findOneAndDelete({ id });
    res.status(200).json(deletedNote);
    return;
  } catch (err) {
    res.status(500).json({ error: "Failed to delete note" });
    return;
  }
}

// extra route to get the number of notes
export async function getNumberOfNotes(req, res) {
  const numberOfNotes = await Notes.countDocuments();
  res.status(200).json({ numberOfNotes });
  return;
}

export async function resetNotes() {
  await Notes.deleteMany({});
  return;
}
```

## 5) In ./backend/routes/notesRouter.js

## Added an extra route to get the number of notes

```javascript
// In ./backend/routes/notesRouter.js

const router = express.Router();

router.get("/", getAllNotes);

router.post("/", createNotes);

router.put("/:id", updateNotes);

router.delete("/:id", deleteNotes);

router.get("/number", getNumberOfNotes);

export default router;
```

## 6)In ./backend/test/notes.test.js

## In the test file we have to connect to db and close the connection and reset the notes

## So that we can test the code properly

```javascript
// Add beforeAll and afterAll to the test file and before each test call the resetNotes function
beforeAll(async () => {
  await connectDB();
});

afterAll(async () => {
  await mongoose.connection.close();
});

beforeEach(async () => {
  await resetNotes();
});
```

## Also added package.json for the backend

## 7) run the tests

```bash
npm run test
```
